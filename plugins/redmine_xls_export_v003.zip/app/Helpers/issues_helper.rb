require 'xls_export_helper'

module IssuesHelper

	include XLSExportHelper
	
end
