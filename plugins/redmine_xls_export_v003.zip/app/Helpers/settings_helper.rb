require 'xls_export_helper'

module SettingsHelper

	include XLSExportHelper
	
end
