
module XLSExportHelper
	unloadable

  def xlse_list_of_fields

    fields = xlse_list_of_columns
    fields << xlse_list_of_options 
    return fields
  end
  
  def xlse_list_of_columns
  	return ['relations','watchers','description', 'time','attachments' ]
  end

  def xlse_list_of_options
  	return ['query_columns_only','group','generate_name']
  end

end
