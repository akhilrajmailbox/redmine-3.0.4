require 'redmine'

# Patches to the Redmine core.
require 'dispatcher'
require 'xls_export'
require 'issues_controller_xls_patch'

Dispatcher.to_prepare :redmine_xls_export do
	
	Mime::Type.register('application/vnd.ms-excel', :xls, %w(application/vnd.ms-excel)) unless defined? Mime::XLS
	
	IssuesController.send(:include, IssuesControllerXLSPatch)
  
end

Redmine::Plugin.register :redmine_xls_export do
  name 'Issues XLS export'
  author 'Vitaly Klimov'
  author_url 'mailto:vvk@snowball.ru'
  description 'This plugin requires spreadsheet gem'
  version '0.0.3'

  settings(:partial => 'settings/xls_export_settings',
           :default => {
             'relations' => '1',
             'watchers' => '1',
             'description' => '1',
             'time' => '0',
             'attachments' => '0',
             'query_columns_only' => '0',
             'group' => '0',
             'generate_name' => '1',
             'issues_limit' => '0',
             'export_name' => 'issues_export'
           })
  
end
